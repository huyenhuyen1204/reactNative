// import DemoPokemon from './src/component/login/login';
// import {
// 	AppRegistry
// }
// from 'react-native';

// AppRegistry.registerComponent('HelloWorld', ()=> DemoPokemon);

import Demo from './src/component/nextScreen/demo';
import {
	AppRegistry
}
from 'react-native';

AppRegistry.registerComponent('HelloWorld', ()=> Demo);